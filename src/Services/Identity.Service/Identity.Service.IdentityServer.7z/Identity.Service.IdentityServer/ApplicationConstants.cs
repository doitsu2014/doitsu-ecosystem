namespace Identity.Service.IdentityServer
{
    public class ApplicationConstants
    {
        public const string CS_CONFIGURATION_DB = "ConfigurationDbConnection";
        public const string CS_PERSISTEDGRANT_DB = "PersistedGrantDbConnection";
        public const string CS_APPLICATION_DB = "ApplicationDbConnection";
    }
}