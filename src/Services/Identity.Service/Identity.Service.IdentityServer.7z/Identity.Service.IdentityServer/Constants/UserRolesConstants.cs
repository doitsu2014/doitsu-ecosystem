namespace Identity.Service.IdentityServer.Constants
{
    public static class UserRolesConstants
    {
        public const string CUSTOMER = "customer";
        public const string ADMIN = "admin";
    }
}