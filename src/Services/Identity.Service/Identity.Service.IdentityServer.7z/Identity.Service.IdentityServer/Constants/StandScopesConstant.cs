namespace Identity.Service.IdentityServer.Constants
{
    public static class StandardScopeConstants
    {
        public const string ADDRESS = "address";
    }
}